# IMPORTS #
import PySimpleGUI as sg
from random import randint
import pendu_trouillon_jaillet as ptj
import time
import os
import sys



# CODE DU JEU #
def login(l_user: list, l_password: list):
    """Permet à l'utilisateur de se connecter à un compte en comparant son nom
       d'utilisateur et son mot de passe à ceux enregistrés dans les fichiers .txt"""
    while True:
        user= sg.popup_get_text('Nom d\'utilisateur')
        password= sg.popup_get_text('Mot de passe')

        if user in l_user and password in l_password:
            if l_user.index(user) == l_password.index(password):
                return user, l_user.index(user)
        elif user not in l_user:
            sg.popup('L\'utilisateur n\'existe pas.', no_titlebar=True)
        elif password not in l_password:
            sg.popup('Le mot de passe est inccorect.', no_titlebar=True)

def creer_compte(l_user: list, l_password: list):
    """ajoute un nom d'utilisateur et le mot de passe correspondant aux fichiers textes
       et permet de s'y connecter"""
    while True:
        nouv_user= sg.popup_get_text('Choisissez votre nom d\'utilisateur.', no_titlebar=True)
        if ',' in nouv_user or len(nouv_user)==0:
            sg.popup('Ce nom d\'utilisateur est impossible.', no_titlebar=True)
        elif nouv_user in l_user:
            sg.popup('Le nom d\'utilisateur n\'est pas disponible.', no_titlebar=True)
        else:
            break

    nouv_mdp= sg.popup_get_text('Choisissez votre mot de passe.', no_titlebar=True)
    
    with open('_user.txt','a') as f_user:
        f_user.write(f',{nouv_user}')
    with open('_password.txt',"a") as f_mdp:
        f_mdp.write(f',{nouv_mdp}')
    with open('_score.txt',"a") as f_scr:
        f_scr.write(',0')

    return nouv_user

def dictionnaire(mots: str) -> list:
    """Renvoie une liste où chaque élément est un string contenant une ligne
       du fichier .txt en argument (minuscules forcées, accents conservés)"""
    with open(mots, encoding='utf-8') as m:
        liste= [line.rstrip('\n') for line in m]
        for i in range(len(liste)):
            liste[i]= liste[i].lower()

    return liste

def choix_mot(liste_mots: list) -> (str, str):
    """Renvoie deux strings en fonction de la liste de strings en argument:
           'mot_cache' contient un mot choisit au hasard dans la liste donnée,
           'mot_public' contient autant d'astérisques que de lettres dans mot_cache"""
    mot_cache= liste_mots[(randint(0, len(liste_mots)))-1]
    mot_public= '*' * len(mot_cache)

    return mot_public, mot_cache

def jeu(mot_public: str, mot_cache: str, essais: int) -> (str, str, int):
    """Renvoie ses arguments modifiés (sauf mot_cache):
           'mot_public' est modifié par la lettre entrée si elle est dans mot_cache,
           'essais' est diminué de 1 si la lettre entrée n'est pas dans mot_cache
       Amorce la fin du jeu (fin('cause'))"""
    lettre= ptj.values['lettre']

    if lettre in mot_cache:
        for i in range(len(mot_cache)):
            if mot_cache[i] == lettre:
                mot_public= mot_public[:i] + lettre + mot_public[i + 1:]
    else:
        essais -= 1

    ptj.fenetre['mot'].update(f'Mot: {mot_public}')
    ptj.fenetre['k_essais'].update(f'Essais restants : {essais}')
    affichage(essais, mot_cache)

    if mot_public == mot_cache:
        fin('gagne', essais)
        pass

    return mot_public, mot_cache, essais

def affichage(essais: int, mot_cache: str):
    """Change l'image affichée en fonction du nombre d'essais restants
       Amorce la fonction fin() si il n'y a plus d'essais"""
    if essais == 9:
        pass
    else:
        ptj.fenetre['im'].update(f'images/pendu_{essais}.png')

    if essais == 0:
        ptj.fenetre['mot'].update(f'Le mot était : {mot_cache}')
        fin('pendu', 0)

def fin(cause, essais):
    """Affiche l'écran de fin correspondant à l'issue de la partie
       Empêche le joueur de continuer a enrgistrer de nouvelles lettres
       Amorce la fonction rejouer()"""
    if cause == 'pendu':
        ptj.fenetre['im'].update('images/pendu_pendu.png')
    elif cause == 'gagne':
        ptj.fenetre['im'].update('images/pendu_gagne.png')

    score(essais)

    ptj.fenetre['Confirmer'].update(disabled= True)

    ptj.fenetre.refresh()
    time.sleep(1)
    rejouer()

def score(points: int):
    """modifie le score de l'utilisateur correspondant dans le fichier .txt
       en y ajoutant le nombre d'essais restants"""
    with open("_score.txt", "r") as f_score :
        r_score=f_score.read()
        l_score=r_score.split(",")

    i_user= ptj.l_user.index(ptj.user)
    score= int(l_score[i_user])
    score+= points
    ptj.fenetre['sc'].update(f'Score : {score}') # marche pas, vérif en déac rejouer() ou fin()

    if i_user == 0:
        l_score[i_user]= str(score)
    else:
        l_score[i_user] = "," + str(score)

    for i in range(1, len(l_score)):
        if i == i_user:
            pass
        else:
            l_score[i]= ',' + l_score[i]

    with open("_score.txt", "w") as point_score:
        point_score.writelines(l_score)

def rejouer():
    """Propose au joueur d'immédiatement relancer une partie.
       Sinon, ferme le jeu complètement."""
    ptj.fenetre.refresh()
    time.sleep(1)

    dispo_fen_rej= [
                    [sg.Text('Voulez vous rejouer ?')],
                    [sg.Button('Oui')], [sg.Button('Non')]
                   ]

    fen_rej= sg.Window('Partie Terminée', dispo_fen_rej)

    while True:
        event2, values2= fen_rej.read()

        if event2 == sg.WIN_CLOSED or event2 == 'Non':
            sys.exit()

        if event2 == 'Oui':
            os.execv(sys.executable, ['python'] + sys.argv)