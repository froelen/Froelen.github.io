# # # # # # # # # # # # # # # # # # # # # #
#                                         #
#    ####   #####  #   #  ####   #   # ©  #
#    #   #  #      ##  #  #   #  #   #    #
#    ####   ###    # # #  #   #  #   #    #
#    #      #      #  ##  #   #  #   #    #
#    #      #####  #   #  ####   #####    #
#                                         #
#           BY PIERRE & MARIUS            #
#                                         #
# # # # # # # # # # # # # # # # # # # # # #



# IMPORTS #
import PySimpleGUI as sg
import code_jeu as cj



# INITIALISATION #
with open('_user.txt', 'r') as file_user:
    r_user = file_user.read()
    l_user = r_user.split(",")

with open('_password.txt', 'r') as file_password:
    r_password = file_password.read()
    l_password = r_password.split(",")

auth= sg.popup('Choisissez votre méthode d\'authentification.', no_titlebar=True, custom_text=('Se connecter', 'S\'enregistrer'))
if auth == 'Se connecter':
    user, i_user= cj.login(l_user, l_password)
elif auth == 'S\'enregistrer':
    user, i_user= cj.creer_compte(l_user, l_password)

essais=9
mot_public, mot_cache = cj.choix_mot(cj.dictionnaire('dictionnaire_fr_simple.txt'))

with open('disclaimer.txt', 'r') as dc:
    attention= dc.read()

    if attention == "Oui":
        attention= sg.popup('''Attention ! Ce jeu accepte tous les caractères et les comptera faux s\'ils ne sont pas des lettres.
Les accents doivent être donnés (inscrire "ê" pour "pêche")
Les majuscules ne changent rien ("P" ou "p" revient au même)
Voulez-vous revoir cette information la prochaine fois ?''', no_titlebar=True, custom_text=('Oui', 'Non'))
# utilisation des triples guillemets pour permettre le retour à la ligne dans la popup.

if attention == "Oui":
    with open('disclaimer.txt', 'w') as dc:
        dc.write('Oui')
else:
    with open('disclaimer.txt', 'w') as dc:
        dc.write('Non')

with open("_score.txt", "r") as f_score:
    r_score=f_score.read()
    l_score=r_score.split(",")
score= l_score[l_user.index(user)]

# PySimpleGUI DISPOSITION #
disposition_fenetre= [
                        [sg.Text(f'Compte : {user}')],
                        [sg.Text(f'Score : {score}', key='sc')],
                        [sg.Image('images/pendu_vide.png',key='im')],
                        [sg.Text(f'Mot : {mot_public}', key='mot')],
                        [sg.Text(f'Essais restants : {essais}', key='k_essais')],
                        [sg.Text('Entrez une lettre')],
                        [sg.Input(key='lettre')],
                        [sg.Button('Confirmer')]
                     ]

fenetre= sg.Window('Jeu Du Pendu', disposition_fenetre)



# AFFICHAGE FENETRE #
while True:
    event, values = fenetre.read()

    if event == sg.WIN_CLOSED:
        break

    if event == 'Confirmer':
        values['lettre']= values['lettre'].lower()

        if values['lettre'] == 'code fin':               # CODE DE TRICHE
            fenetre['mot'].update(f'{mot_cache}')
            cj.fin('gagne', essais)
        elif len(values['lettre']) != 1:
            sg.popup('Attention à n\'entrer qu\'une seule lettre !', no_titlebar=True)
        else:
            mot_public, mot_cache, essais= cj.jeu(mot_public, mot_cache, essais)
            cj.affichage(essais, mot_cache)